El archivo comprimido MALWARE.zip contiene troyanos obtenidos en el proceso de investigación. NO USAR BAJO EXCEPTO PARA INVESTIGACIÓN.
La contraseña es: estoyseguro